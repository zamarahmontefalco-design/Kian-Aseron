# Personal Portfolio — Netlify Ready

## Run locally
Open `index.html` in a browser.

## Deploy to Netlify
1. Go to Netlify.
2. Choose **Add new project / Deploy manually**.
3. Drag the entire `portfolio` folder into the deploy area.
4. Your site is live.

## Profile photo
Click **Upload my photo** on the profile card. The image is displayed locally in the browser; no server or database is required.

Edit the name, text, colors, cards, and tags directly in `index.html` and `style.css`.
