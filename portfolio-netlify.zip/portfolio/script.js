const upload = document.getElementById("photoUpload");
const photo = document.getElementById("profilePhoto");
const placeholder = document.getElementById("photoPlaceholder");

upload.addEventListener("change", (event) => {
  const file = event.target.files?.[0];
  if (!file || !file.type.startsWith("image/")) return;

  const reader = new FileReader();
  reader.onload = () => {
    photo.src = reader.result;
    photo.style.display = "block";
    placeholder.style.display = "none";
  };
  reader.readAsDataURL(file);
});
